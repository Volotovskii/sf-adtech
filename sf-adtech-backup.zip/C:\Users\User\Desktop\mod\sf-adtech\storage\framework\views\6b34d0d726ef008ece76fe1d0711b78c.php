

<?php $__env->startSection('content'); ?>
    <h1>Статистика (Admin)</h1>

    <form method="GET" action="<?php echo e(route('admin.stats')); ?>">
        <select name="group_by">
            <option value="day" <?php echo e(request('group_by') === 'day' ? 'selected' : ''); ?>>По дням</option>
            <option value="hour" <?php echo e(request('group_by') === 'hour' ? 'selected' : ''); ?>>По часам</option>
            <option value="minute" <?php echo e(request('group_by') === 'minute' ? 'selected' : ''); ?>>По минутам</option>
        </select>
        <button type="submit">Применить</button>
    </form>

    <canvas id="adminChart" width="400" height="200"
            data-data="<?php echo e(json_encode($stats->pluck('count'))); ?>"
            data-labels="<?php echo e(json_encode($stats->pluck('period'))); ?>"></canvas>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/admin-stats.js']); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\mod\sf-adtech\resources\views/admin/stats.blade.php ENDPATH**/ ?>