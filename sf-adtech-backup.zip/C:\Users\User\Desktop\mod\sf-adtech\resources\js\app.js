import './bootstrap';

import 'bootstrap/dist/js/bootstrap.bundle.min.js'; // ПРоверить


import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
