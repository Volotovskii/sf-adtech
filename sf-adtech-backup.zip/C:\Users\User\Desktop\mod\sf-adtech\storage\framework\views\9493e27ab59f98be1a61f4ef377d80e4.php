

<?php $__env->startSection('content'); ?>
<h1>Статистика (Advertiser)</h1>


<?php if(isset($totalCosts)): ?>
<p class="total-costs">Всего потрачено: <?php echo e(number_format($totalCosts, 2, '.', ' ')); ?> руб.</p>
<?php endif; ?>


<form method="GET" action="<?php echo e(route('advertiser.stats')); ?>" id="statsFilterForm">
    <div class="form-group mb-3">
        <label for="group_by">Группировать по:</label>
        <select name="group_by" id="group_by" class="form-control">
            <option value="day" <?php echo e(request('group_by') === 'day' ? 'selected' : ''); ?>>По дням</option>
            <option value="hour" <?php echo e(request('group_by') === 'hour' ? 'selected' : ''); ?>>По часам</option>
            <option value="minute" <?php echo e(request('group_by') === 'minute' ? 'selected' : ''); ?>>По минутам</option>
        </select>
    </div>

    <div class="form-group mb-3">
        <label for="offerFilter">Выберите оффер:</label>
        <select name="offer_id" id="offerFilter" class="form-control"> 
            <option value="">Все офферы</option>
            <?php $__currentLoopData = $offerDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($id); ?>" <?php echo e(request('offer_id') == $id ? 'selected' : ''); ?>><?php echo e($details['name']); ?></option> <!-- ДОБАВЛЕНО selected -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <button type="submit" class="btn btn-primary">Применить</button>
</form>

<!-- Контейнер для графиков -->
<div class="row">
    <div class="col-md-12">
        <h4>Количество переходов</h4>
        <canvas id="clicksChart" width="400" height="100"></canvas>
    </div>
    <div class="col-md-12 mt-4">
        <h4>Расходы (руб.)</h4>
        <canvas id="costsChart" width="400" height="100"></canvas>
    </div>
</div>


<script>
    window.appData = {
        allStats: <?php echo json_encode($allStats, 15, 512) ?>,
        allCosts: <?php echo json_encode($allCosts, 15, 512) ?>
    };
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/advertiser-stats.js']); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\mod\sf-adtech\resources\views/advertiser/stats.blade.php ENDPATH**/ ?>