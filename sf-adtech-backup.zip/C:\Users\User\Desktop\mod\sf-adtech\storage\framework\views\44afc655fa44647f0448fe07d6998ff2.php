

<?php $__env->startSection('content'); ?>
<h1>Веб-мастер Dashboard</h1>

<?php if(session('status')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>

<p>Добро пожаловать, <?php echo e(auth()->user()->name); ?>!</p>

<a href="<?php echo e(route('webmaster.offers')); ?>" class="btn btn-primary">Доступные офферы</a>
<a href="<?php echo e(route('webmaster.links')); ?>" class="btn btn-success">Мои ссылки</a>
<a href="<?php echo e(route('webmaster.stats')); ?>" class="btn btn-info">Статистика</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\mod\sf-adtech\resources\views/webmaster/dashboard.blade.php ENDPATH**/ ?>