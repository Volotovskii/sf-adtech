

<?php $__env->startSection('content'); ?>
<h1>Мои ссылки</h1>

<table class="table table-striped">
    <thead>
        <tr>
            <th>Оффер</th>
            <th>Целевой URL</th>
            <th>Статус</th>
            <th>Ссылка</th>
            <th>Действие</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $offer = $subscription->offer;
        $isTrashed = $offer && $offer->trashed();
        $isOfferActive = $offer && $offer->is_active;
        $isSubscribed = $subscription->is_active;
        ?>
        <tr class="
                    <?php if($isSubscribed && $isOfferActive && !$isTrashed): ?>
                        table-success
                    <?php elseif(!$isSubscribed || !$isOfferActive): ?>
                        table-warning
                    <?php elseif($isTrashed): ?>
                        table-secondary
                    <?php endif; ?>
                "
            data-previous-markup="<?php echo e($subscription->markup); ?>"
            data-webmaster-id="<?php echo e(auth()->id()); ?>">
            <td>
                <?php if($isTrashed): ?>
                [АРХИВ] <?php echo e($offer->name); ?>

                <?php elseif(!$isOfferActive): ?>
                [НЕАКТИВЕН] <?php echo e($offer->name); ?>

                <?php else: ?>
                <?php echo e($offer->name); ?>

                <?php endif; ?>
            </td>
            <td><?php echo e($offer->target_url ?? 'N/A'); ?></td>
            <td>
                <?php if($isSubscribed && $isOfferActive && !$isTrashed): ?>
                <span class="badge bg-success">Активна</span>
                <?php elseif(!$isSubscribed): ?>
                <span class="badge bg-warning">Отписался</span>
                <?php elseif(!$isOfferActive): ?>
                <span class="badge bg-danger">Оффер неактивен</span>
                <?php elseif($isTrashed): ?>
                <span class="badge bg-secondary">Оффер удалён</span>
                <?php endif; ?>
            </td>
            <td>
                <?php if($isSubscribed && $isOfferActive && !$isTrashed): ?>
                <input type="text" class="form-control" value="<?php echo e(url('/go/' . $offer->id . '?webmaster_id=' . auth()->id())); ?>" readonly>
                <?php else: ?>
                <input type="text" class="form-control" value="Ссылка недоступна" readonly disabled>
                <?php endif; ?>
            </td>
            <td>
                <?php if($isSubscribed && $isOfferActive && !$isTrashed): ?>
                <!-- Кнопка отписки -->
                <form method="POST" action="<?php echo e(route('webmaster.unsubscribe', $offer->id)); ?>" class="d-inline unsubscribe-form-links" id="unsubscribe-form-<?php echo e($offer->id); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Отписаться?')">Отписаться</button>
                </form>
                <?php elseif(!$isSubscribed): ?>
                <!-- Кнопка "Возобновить" -->
                <form method="POST" action="<?php echo e(route('webmaster.subscribe', $offer->id)); ?>" class="d-inline subscribe-form-links" id="subscribe-form-<?php echo e($offer->id); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="number" name="markup" value="<?php echo e($subscription->markup); ?>" step="0.01" min="0">
                    <button type="submit" class="btn btn-success btn-sm">Возобновить</button>
                </form>
                <?php else: ?>
                <span>Недоступно</span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/webmaster-links.js']); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\mod\sf-adtech\resources\views/webmaster/links.blade.php ENDPATH**/ ?>