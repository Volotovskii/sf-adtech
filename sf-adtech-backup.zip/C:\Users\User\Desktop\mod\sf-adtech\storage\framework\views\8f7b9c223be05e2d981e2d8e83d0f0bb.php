

<?php $__env->startSection('content'); ?>
    <h1>Рекламодатель Dashboard</h1>
    
    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
    <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <p>Добро пожаловать, <?php echo e(auth()->user()->name); ?>!</p>

    <a href="<?php echo e(route('advertiser.offers.index')); ?>" class="btn btn-primary">Мои офферы</a>
    <a href="<?php echo e(route('advertiser.stats')); ?>" class="btn btn-info">Статистика</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\mod\sf-adtech\resources\views/advertiser/dashboard.blade.php ENDPATH**/ ?>