

<?php $__env->startSection('content'); ?>
<h1>Доступные офферы</h1>

<!-- Доска с колонками -->
<div class="board">
    <!-- Активные офферы (доступные для подписки) -->
    <div class="column" data-column="active">
        <h3>Активные офферы</h3>

        <?php $__currentLoopData = $availableOffers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="offer-item offer-active" draggable="true" data-id="<?php echo e($offer->id); ?>">
                <div class="offer-header">
                    <?php if($offer->trashed()): ?>
                        [АРХИВ] <?php echo e($offer->name); ?>

                    <?php else: ?>
                        <?php echo e($offer->name); ?>

                    <?php endif; ?>
                </div>
                <div class="offer-details">
                    <strong>Целевой URL:</strong> <?php echo e($offer->target_url); ?><br>
                    <strong>Цена за клик:</strong> <span id="cost-per-click-<?php echo e($offer->id); ?>"><?php echo e($offer->cost_per_click); ?></span>
                    <!-- Контейнер для наценки, изначально пустой для доступных офферов -->
                    <span id="markup-display-<?php echo e($offer->id); ?>" class="markup-display" style="display: none;"><br><strong>Наценка:</strong> <span class="markup-value"></span></span>
                </div>
                <div class="offer-actions">
                    <form method="POST" action="<?php echo e(route('webmaster.subscribe', $offer->id)); ?>" class="d-inline subscribe-form">
                        <?php echo csrf_field(); ?>
                        <input type="number" name="markup" placeholder="Наценка" step="0.01" min="0" required class="form-control-sm d-inline-block w-auto" draggable="false">
                        <button type="submit" class="btn btn-primary btn-sm">Подписаться</button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Подписки -->
    <div class="column" data-column="subscribed">
        <h3>Мои подписки</h3>
        <?php $__currentLoopData = $subscribedOffers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                // $subscription->offer гарантированно существует и не удалён благодаря фильтрации в контроллере
                $relatedOffer = $subscription->offer;
            ?>
            <div class="offer-item offer-subscribed" draggable="true" data-id="<?php echo e($relatedOffer->id); ?>"> <!-- Используем ID оффера -->
                <div class="offer-header">
                    <?php echo e($relatedOffer->name); ?>

                </div>
                <div class="offer-details">
                    <strong>Целевой URL:</strong> <?php echo e($relatedOffer->target_url); ?><br>
                    <strong>Цена за клик:</strong> <span id="cost-per-click-<?php echo e($relatedOffer->id); ?>"><?php echo e($relatedOffer->cost_per_click); ?></span>
                    <!-- Контейнер для наценки -->
                    <span id="markup-display-<?php echo e($relatedOffer->id); ?>" class="markup-display"><br><strong>Наценка:</strong> <span class="markup-value"><?php echo e($subscription->markup); ?></span></span>
                </div>
                <div class="offer-actions">
                    <form method="POST" action="<?php echo e(route('webmaster.unsubscribe', $relatedOffer->id)); ?>" class="d-inline unsubscribe-form" data-offer-id="<?php echo e($relatedOffer->id); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Отписаться?')">Отписаться</button>
                    </form>
                    <form method="POST" action="<?php echo e(route('webmaster.update-markup', $relatedOffer->id)); ?>" class="d-inline update-markup-form" data-offer-id="<?php echo e($relatedOffer->id); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="number" name="markup" value="<?php echo e($subscription->markup); ?>" step="0.01" min="0" draggable="false">
                        <button type="submit" class="btn btn-warning btn-sm">Изменить</button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/webmaster-offers.js']); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\mod\sf-adtech\resources\views/webmaster/offers.blade.php ENDPATH**/ ?>