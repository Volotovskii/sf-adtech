

<?php $__env->startSection('content'); ?>
    <h1>Мои офферы</h1>

    <a href="<?php echo e(route('advertiser.offers.create')); ?>" class="btn btn-success mb-3">Создать оффер</a>

    <!-- Доска с колонками -->
    <div class="board">
        <!-- <div class="column" data-status="draft" ondrop="drop(event)" ondragover="allowDrop(event)"> -->
        <div class="column" data-status="draft">
            <h3>Черновик</h3>
            <?php $__currentLoopData = $offers->where('status', 'draft'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- <div class="offer-item" draggable="true" ondragstart="drag(event)" data-id="<?php echo e($offer->id); ?>"> -->
                <div class="offer-item draft" draggable="true" data-id="<?php echo e($offer->id); ?>">
                    <div class="offer-header">
                        <?php echo e($offer->name); ?>

                    </div>
                    <div class="offer-details">
                        <strong>Целевой URL:</strong> <?php echo e($offer->target_url); ?><br>
                        <strong>Цена за клик:</strong> <?php echo e($offer->cost_per_click); ?><br>
                        <strong>Подписчиков:</strong> <?php echo e($offer->subscribers_count); ?>

                    </div>
                    <div class="offer-actions">
                        <a href="<?php echo e(route('advertiser.offers.edit', $offer)); ?>" class="btn btn-sm btn-primary">Редактировать</a>
                        <form method="POST" action="<?php echo e(route('advertiser.offers.destroy', $offer)); ?>" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Удалить?')">Удалить</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- <div class="column" data-status="active" ondrop="drop(event)" ondragover="allowDrop(event)"> -->
        <div class="column" data-status="active">
            <h3>Активен</h3>
            <?php $__currentLoopData = $offers->where('status', 'active'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- <div class="offer-item active" draggable="true" ondragstart="drag(event)" data-id="<?php echo e($offer->id); ?>"> -->
                <div class="offer-item active" draggable="true" data-id="<?php echo e($offer->id); ?>">
                    <div class="offer-header">
                        <?php echo e($offer->name); ?>

                    </div>
                    <div class="offer-details">
                        <strong>Целевой URL:</strong> <?php echo e($offer->target_url); ?><br>
                        <strong>Цена за клик:</strong> <?php echo e($offer->cost_per_click); ?><br>
                        <strong>Подписчиков:</strong> <?php echo e($offer->subscribers_count); ?>

                    </div>
                    <div class="offer-actions">
                        <a href="<?php echo e(route('advertiser.offers.edit', $offer)); ?>" class="btn btn-sm btn-primary">Редактировать</a>
                        <form method="POST" action="<?php echo e(route('advertiser.offers.destroy', $offer)); ?>" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Удалить?')">Удалить</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- <div class="column" data-status="inactive" ondrop="drop(event)" ondragover="allowDrop(event)"> -->
         <div class="column" data-status="inactive">
            <h3>Неактивен</h3>
            <?php $__currentLoopData = $offers->where('status', 'inactive'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- <div class="offer-item inactive" draggable="true" ondragstart="drag(event)" data-id="<?php echo e($offer->id); ?>"> -->
                <div class="offer-item inactive" draggable="true" data-id="<?php echo e($offer->id); ?>">
                    <div class="offer-header">
                        <?php echo e($offer->name); ?>

                    </div>
                    <div class="offer-details">
                        <strong>Целевой URL:</strong> <?php echo e($offer->target_url); ?><br>
                        <strong>Цена за клик:</strong> <?php echo e($offer->cost_per_click); ?><br>
                        <strong>Подписчиков:</strong> <?php echo e($offer->subscribers_count); ?>

                    </div>
                    <div class="offer-actions">
                        <a href="<?php echo e(route('advertiser.offers.edit', $offer)); ?>" class="btn btn-sm btn-primary">Редактировать</a>
                        <form method="POST" action="<?php echo e(route('advertiser.offers.destroy', $offer)); ?>" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Удалить?')">Удалить</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

   
<?php $__env->stopSection(); ?>

    <!-- JavaScript для Drag & Drop -->
<?php $__env->startPush('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/advertiser-offers.js']); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\mod\sf-adtech\resources\views/advertiser/offers/index.blade.php ENDPATH**/ ?>