

<?php $__env->startSection('content'); ?>
<h1>Редактировать оффер</h1>

<form method="POST" action="<?php echo e(route('advertiser.offers.update', $offer)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="mb-3">
        <label for="name" class="form-label">Название</label>
        <input type="text" name="name" id="name" class="form-control" value="<?php echo e(old('name', $offer->name)); ?>" required>
    </div>

    <div class="mb-3">
        <label for="target_url" class="form-label">Целевой URL</label>
        <input type="url" name="target_url" id="target_url" class="form-control" value="<?php echo e(old('target_url', $offer->target_url)); ?>" required>
    </div>

    <div class="mb-3">
        <label for="cost_per_click" class="form-label">Цена за клик</label>
        <input type="number" name="cost_per_click" id="cost_per_click" class="form-control" step="0.01" value="<?php echo e(old('cost_per_click', $offer->cost_per_click)); ?>" required>
    </div>

    <div class="mb-3">
        <label for="category" class="form-label">Категория</label>
        <input type="text" name="category" id="category" class="form-control" value="<?php echo e(old('category', $offer->category)); ?>">
    </div>

    <!-- Без 0 не отпрпаляет в форме хм  -->
    <div class="mb-3 form-check">
        <input type="hidden" name="is_active" value="0">
        <input type="checkbox" name="is_active" id="is_active" class="form-check-input" value="1" <?php echo e($offer->is_active ? 'checked' : ''); ?>>
        <label for="is_active" class="form-check-label">Активен</label>
    </div>
    <div class="mb-3">
        <label for="status" class="form-label">Статус</label>
        <select name="status" id="status" class="form-control" required>
            <option value="draft" <?php echo e($offer->status === 'draft' ? 'selected' : ''); ?>>Черновик</option>
            <option value="active" <?php echo e($offer->status === 'active' ? 'selected' : ''); ?>>Активен</option>
            <option value="inactive" <?php echo e($offer->status === 'inactive' ? 'selected' : ''); ?>>Неактивен</option>
        </select>
    </div>

    <button type="submit" class="btn btn-primary">Сохранить</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\mod\sf-adtech\resources\views/advertiser/offers/edit.blade.php ENDPATH**/ ?>