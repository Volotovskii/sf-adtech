<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SF-AdTech</title>

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>
        <noscript>
        <div style="padding: 1rem; background-color: #fff3cd; color: #856404; border: 1px solid #ffeaa7; margin: 0; text-align: center; z-index: 9999; position: relative;">
            <p><strong>Внимание!</strong> Для корректной работы всех функций этого сайта включите JavaScript в настройках вашего браузера. Некоторые интерактивные элементы могут не работать.</p>
        </div>
    </noscript>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">SF-AdTech</a>
            <div class="navbar-nav ms-auto">
                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->role === 'admin'): ?>
                        <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">Admin</a>
                        <a class="nav-link" href="<?php echo e(route('admin.users')); ?>">Users</a>
                        <a class="nav-link" href="<?php echo e(route('admin.system-stats')); ?>">System Stats</a>
                        <a class="nav-link" href="<?php echo e(route('admin.pending-users')); ?>">Pending</a>
                    <?php elseif(auth()->user()->role === 'advertiser'): ?>
                        <a class="nav-link" href="<?php echo e(route('advertiser.dashboard')); ?>">Advertiser</a>
                    <?php elseif(auth()->user()->role === 'webmaster'): ?>
                        <a class="nav-link" href="<?php echo e(route('webmaster.dashboard')); ?>">Webmaster</a>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-link nav-link">Logout</button>
                    </form>
                <?php else: ?>
                    <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                    <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\Users\User\Desktop\mod\sf-adtech\resources\views/layouts/app.blade.php ENDPATH**/ ?>