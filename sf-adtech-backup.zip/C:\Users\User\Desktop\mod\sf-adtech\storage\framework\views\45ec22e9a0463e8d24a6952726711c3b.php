

<?php $__env->startSection('content'); ?>
<h1>Статистика (Веб-мастер)</h1>

<div class="filters-container">
    <form method="GET" action="<?php echo e(route('webmaster.stats')); ?>">
        <div class="filter-group">
            <label for="group_by">Группировка:</label>
            <select name="group_by" id="group_by">
                <option value="day" <?php echo e(request('group_by') === 'day' ? 'selected' : ''); ?>>По дням</option>
                <option value="hour" <?php echo e(request('group_by') === 'hour' ? 'selected' : ''); ?>>По часам</option>
                <option value="minute" <?php echo e(request('group_by') === 'minute' ? 'selected' : ''); ?>>По минутам</option>
                <option value="month" <?php echo e(request('group_by') === 'month' ? 'selected' : ''); ?>>По месяцам</option>
                <option value="year" <?php echo e(request('group_by') === 'year' ? 'selected' : ''); ?>>По годам</option>
            </select>
        </div>

        <div class="filter-group">
            <label for="offer_id">Оффер:</label>
            <select name="offer_id" id="offer_id">
                <option value="">Все офферы</option>
                <?php $__currentLoopData = $allSubscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($subscription->offer->id); ?>" <?php echo e(request('offer_id') == $subscription->offer->id ? 'selected' : ''); ?>>
                    <?php echo e($subscription->offer->trashed() ? '[АРХИВ] ' : ''); ?>

                    <?php echo e($subscription->is_active ? '' : '[НЕАКТИВЕН] '); ?>

                    <?php echo e($subscription->offer->name); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="filter-group">
            <label for="status">Статус:</label>
            <select name="status" id="status">
                <option value="">Все</option>
                <option value="active" <?php echo e(request('status') === 'active' ? 'selected' : ''); ?>>Активные</option>
                <option value="inactive" <?php echo e(request('status') === 'inactive' ? 'selected' : ''); ?>>Неактивные</option>
                <option value="archived" <?php echo e(request('status') === 'archived' ? 'selected' : ''); ?>>Архив</option>
            </select>
        </div>

        <button type="submit" class="btn-apply">Применить</button>
    </form>
</div>

<p class="total-earnings">Всего заработано: <?php echo e(number_format($totalEarnings, 2)); ?> руб.</p>

<!-- Контейнер для графиков -->
<div class="row">
    <div class="col-md-6">
        <h4>Количество переходов</h4>
        <canvas id="clicksChart" width="400" height="200"></canvas>
    </div>
    <div class="col-md-6">
        <h4>Доходы (руб.)</h4>
        <canvas id="earningsChart" width="400" height="200"></canvas>
    </div>
</div>
<script>
    window.appData = {
        allClicks: <?php echo json_encode($allClicks, 15, 512) ?>,
        allEarnings: <?php echo json_encode($allEarnings, 15, 512) ?>
    };
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/webmaster-stats.js']); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\mod\sf-adtech\resources\views/webmaster/stats.blade.php ENDPATH**/ ?>